{\rtf1\ansi\ansicpg1252\cocoartf1671\cocoasubrtf100
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 Name: Camille d\'92Abreu\
JDK Used: Oracle 12\
IDE Used: Eclipse version 2019-03 (4.11.0)\
Main File: BankTester.java\
LoadFile: the move file is named BankDB.txt and the \'93location\'94 variable must be changed to reflect the location within the running computer. Currently, it is hardcoded to \'93\cf2 /Users/Camille/Documents/Assignment0/src/bankAssignment/bankDB.txt\'94.\
}